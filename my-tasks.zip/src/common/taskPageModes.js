export const LIST= 'LIST';
export const NEW_ITEM='NEW_ITEM';
export const NO_SELECTION='NO_SELECTION';
export const SHOW_ITEM= 'SHOW_ITEM';
export const EDIT= 'EDIT';
export const DELETE= 'DELETE';

